package com.yaps.petstore.exception;

/**
 * This exception is thrown when an object is not found in the hashmap.
 */
public final class ObjectNotFoundException extends FinderException {

	//public ObjectNotFoundException(String message) {
	//	super(message);
	//}
}
