package com.yaps.petstore.server.service.catalog;

public interface CatalogServiceHome {
	static final String JNDI_NAME = "java:global/yapswtp11/CatalogSB!com.yaps.petstore.server.service.catalog.CatalogService";
}
